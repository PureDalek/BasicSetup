# Install Ubuntu (This will open the Microsoft Store to the Ubuntu page)
# For automation without the Store, use the wsl --install -d <DistributionName> command if supported in your WSL version
wsl --install -d Ubuntu
